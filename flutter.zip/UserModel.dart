class UserModel {
  String userFName;
  String userLName;
  String userEmail;
  String userUid;
  UserModel({
    required this.userEmail,
    required this.userFName,
    required this.userLName,
    required this.userUid,
  });
}